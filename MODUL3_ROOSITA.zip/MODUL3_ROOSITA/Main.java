package MODUL3_ROOSITA;

import java.util.Scanner;
import java.util.InputMismatchException;

public class Main {
    public static void main(String[] args){
        try(Scanner input = new Scanner(System.in)){
            Calculation clc = new Calculation();
            int Square, Circle, Trapezoid;
            try {

                System.out.println(s:"==Menu Program==")
                System.out.println(s:"1. Square")
                System.out.println(s:"2. Circle")
                System.out.println(s:"3. Trapezoid")
                System.out.println(s:"Select menu :")


            }
        }
    }
    
}
