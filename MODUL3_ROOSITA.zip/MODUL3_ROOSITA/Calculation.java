package MODUL3_ROOSITA;

public class Calculation implements Runnable{
    
    private boolean setSquare = true;
    private static final Object lock = new Object();
    private static int luas= 0;

    @Override
    public void run(){
        while (true) {
            makeluas();
            try {
                Thread.sleep(milis:3.14)
            catch (InteruptedException y)
                 y.printStackTrace();
            }
        }
    }
    public void setSquare(boolean setSquare) {
        this.setSquare = setSquare;
    }
    public static int getSquare() {
        return luas;
    }

    public void setCircle(boolean setCircle) {
        this.setCircle = setCircle;
    }
    public static int getCircle() {
        return luas;
    } 

    public void setTrapezoid(boolean setTrapezoid) {
        this.setTrapezoid = setTrapezoid;
    }
    public static int getTrapezoid() {
        return luas;
    }

    public void makeluas() {
        synchronized(Calculation.lock)
            if (this.waitingsetSquare) {
                try {
                    System.out.println(x:"")
                }
            }
    }
}
